<div align="center">

# 🚀 Front-End Development — by Saad Nasir

### Documenting my journey from zero to professional Front-End Developer — in public.

[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)](./01-html)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)](./02-css)
[![Bootstrap](https://img.shields.io/badge/Bootstrap-7952B3?style=for-the-badge&logo=bootstrap&logoColor=white)](./03-bootstrap)
[![Tailwind](https://img.shields.io/badge/Tailwind-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)](./04-tailwind-css)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](./05-javascript)
[![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)](./06-git-github)
[![React](https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black)](./07-react)

![Last Commit](https://img.shields.io/github/last-commit/saad18-dot/Front-End-Dev-By-Saad?style=flat-square)
![Repo Size](https://img.shields.io/github/repo-size/saad18-dot/Front-End-Dev-By-Saad?style=flat-square)
![License](https://img.shields.io/github/license/saad18-dot/Front-End-Dev-By-Saad?style=flat-square)

</div>

---

## 👋 About Me

I'm Saad, learning front-end development from scratch and documenting every step publicly. This repository is not a finished portfolio — it's a transparent, dated record of how I got there: what I studied, what I built, what I got wrong, and how that changed over time.

*(Add: your location, current role/student status, and a one-line goal — e.g. "Currently learning full-time, targeting a Junior Front-End role by [month/year].")*

📫 **Reach me:** [LinkedIn](#) · [Email](#) · [Portfolio site](#) *(links to be added)*

---

## 📌 Repository Purpose

This repo exists to do three things at once:

1. **Force consistency** — a public, dated log is harder to abandon than a private notes app.
2. **Prove skill progression** — anyone (recruiter, mentor, future me) can see the difference between my Week 1 code and my Week 8 code.
3. **Separate learning from output** — notes live with the technology; finished, deployed work lives in [`/projects`](./projects).

---

## 📖 Table of Contents

- [My Learning Journey](#-my-learning-journey)
- [Tech Stack](#-tech-stack)
- [Repository Structure](#-repository-structure)
- [Folder Guide](#-folder-guide)
- [Projects](#-projects)
- [Progress Tracker](#-progress-tracker)
- [Notes & Documentation](#-notes--documentation)
- [Future Goals](#-future-goals)
- [How to Navigate This Repo](#-how-to-navigate-this-repo)
- [Contributing](#-contributing)
- [Contact](#-contact)

---

## 🗺️ My Learning Journey

Full day-by-day roadmap with live status lives in **[ROADMAP.md](./ROADMAP.md)**. Short version:

```
HTML5 → CSS3 → Flexbox → Grid → Responsive Design → Bootstrap → Tailwind CSS
   → JavaScript → DOM → ES6+ → APIs → Git & GitHub → React → (next: TypeScript, Testing, Next.js)
```

I don't skip stages even when a later topic looks more interesting — gaps in fundamentals show up later as bugs I can't debug.

---

## 🛠️ Tech Stack

| Category | Technologies |
|---|---|
| **Markup & Styling** | HTML5, CSS3, Flexbox, CSS Grid, Bootstrap, Tailwind CSS |
| **Programming** | JavaScript (ES6+), DOM APIs, Fetch/REST APIs |
| **Framework** | React |
| **Tools** | Git, GitHub, VS Code, Chrome DevTools |
| **Coming next** | TypeScript, Testing (Jest/RTL), Next.js |

---

## 📁 Repository Structure

```text
Front-End-Dev-By-Saad/
│
├── README.md                 → you are here
├── ROADMAP.md                → full learning path + live status tracker
├── LICENSE
├── .gitignore
│
├── 01-html/                  → notes + exercises, numbered by learning order
├── 02-css/
├── 03-bootstrap/
├── 04-tailwind-css/
├── 05-javascript/
├── 06-git-github/
├── 07-react/
│
└── projects/                  → all finished, deployed work — never mixed with notes
    ├── 01-mini-projects/
    ├── 02-landing-pages/
    ├── 03-javascript-projects/
    ├── 04-responsive-websites/
    ├── 05-react-projects/
    ├── 06-clone-projects/
    ├── 07-portfolio/          → "My Personal Portfolio Website" (running project)
    └── 08-student-resource-hub/  → bonus project (sign-up form, iframe, table)
```

**Why this shape, specifically:**
- **Numbered tech folders** mean the learning order is visible in the file listing itself — no explanation needed.
- **`projects/` is separate from the tech folders** because that's the first thing a recruiter clicks, and it shouldn't be buried inside notes.
- **Every folder has its own `README.md`**, so the repo is self-explaining at every level, not just at the root.

---

## 📂 Folder Guide

| Folder | Purpose |
|---|---|
| [`01-html`](./01-html) | HTML5 notes and small practice exercises |
| [`02-css`](./02-css) | CSS3, Flexbox, Grid, responsive design notes and exercises |
| [`03-bootstrap`](./03-bootstrap) | Bootstrap notes and component practice |
| [`04-tailwind-css`](./04-tailwind-css) | Tailwind CSS notes and component practice |
| [`05-javascript`](./05-javascript) | JavaScript, DOM, ES6+, and API notes and exercises |
| [`06-git-github`](./06-git-github) | Version control notes and workflow reference |
| [`07-react`](./07-react) | React notes and exercises |
| [`projects`](./projects) | All finished, deployed projects, categorized by type |

---

## 💼 Projects

All finished work lives in [`/projects`](./projects), categorized by type rather than by date, so a recruiter can jump straight to what they care about (e.g. React work) without scrolling through everything.

| Category | Description |
|---|---|
| [Mini Projects](./projects/01-mini-projects) | Small single-concept builds |
| [Landing Pages](./projects/02-landing-pages) | Static responsive landing pages |
| [JavaScript Projects](./projects/03-javascript-projects) | Interactive vanilla-JS apps |
| [Responsive Websites](./projects/04-responsive-websites) | Multi-page responsive sites |
| [React Projects](./projects/05-react-projects) | React apps and components |
| [Clone Projects](./projects/06-clone-projects) | UI clones built for practice (clearly labeled as such) |
| [Portfolio](./projects/07-portfolio) | My personal portfolio site — 4 pages, built level by level through the HTML course |
| [Student Resource Hub](./projects/08-student-resource-hub) | Bonus project — sign-up form, iframe embed, and a topics table |

*Projects are added as I finish them — check [ROADMAP.md](./ROADMAP.md) for what's currently in progress.*

---

## 📊 Progress Tracker

| Stage | Status |
|---|---|
| HTML5 | ✅ Core tags complete — notes + portfolio project done |
| CSS3 / Flexbox / Grid / Responsive | ⏳ Not Started |
| Bootstrap | ⏳ Not Started |
| Tailwind CSS | ⏳ Not Started |
| JavaScript / DOM / ES6+ / APIs | ⏳ Not Started |
| Git & GitHub | ⏳ Not Started |
| React | ⏳ Not Started |

Full breakdown with topic-level detail: **[ROADMAP.md](./ROADMAP.md)**

---

## 📚 Notes & Documentation

- Technology-specific notes live **inside each numbered folder** (e.g. [`01-html/README.md`](./01-html)) — co-located with the code they explain, written in my own words rather than copy-pasted from docs.
- Small practice files and working copies of my main project live in each tech folder's `exercises/` subfolder — e.g. [`01-html/exercises`](./01-html/exercises).

---

## 🎯 Future Goals

- [ ] Finish HTML → React fundamentals (this repo's current roadmap)
- [ ] Learn TypeScript
- [ ] Learn testing (Jest, React Testing Library)
- [ ] Learn Next.js
- [ ] Deploy every project in `/projects` live (Vercel/Netlify)
- [ ] Land a Junior Front-End Developer role
- [ ] Keep this repo growing past that point — it doesn't stop at "hired"

---

## 🤝 Contributing

This is a personal learning log, so it's not open for external contributions in the usual sense — but if you spot an error in my notes or have a suggestion, feel free to open an issue. I'd genuinely rather be corrected than stay wrong.

---

## 📬 Contact

- **LinkedIn:** *(add link)*
- **Email:** *(add email)*
- **Portfolio:** *(add link once `/projects/07-portfolio` is deployed)*

---

<div align="center">

*This repository is updated regularly as I learn. Last major structure update: 2026.*

</div>
