# Student Resource Hub (Bonus Project)

A resource website for college students — the bonus project idea from the HTML course, built to practice sign-up forms, `<iframe>` embeds, and tables all in one page.

## Features
- Sign-up form (username, email, password)
- Table listing topics covered on the site
- An embedded coding-reference video/page via `<iframe>`

## File
- `index.html`

## Status
🔄 In Progress — this becomes a real resume-worthy project once CSS, JavaScript, and a back-end are added on top of it (per the course's own note: "if you learn CSS, JS or back-end, this becomes a full mini project").
