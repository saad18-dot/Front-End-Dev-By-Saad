# My Personal Portfolio Website

My running portfolio project, built level by level throughout the HTML course. Pure HTML — no CSS or JS yet, that comes later.

## Pages
| File | Purpose |
|---|---|
| `portfolio/index.html` | Home page — intro, clickable profile image, Contact Me form |
| `portfolio/education.html` | Education details (uses `<sub>`/`<sup>` for CGPA/percentage) |
| `portfolio/experience.html` | Experience & learning timeline |
| `portfolio/projects.html` | Table of all projects built so far |

## Built in parts (matches the course levels)
- **Part 1** (after Level 1): `index.html` created with boilerplate, printed "Portfolio"
- **Part 2** (after Level 2): added `education.html`, `experience.html`, `projects.html`, all linked via anchor tags, using headings/paragraphs/sub/sup
- **Part 3** (after Level 3): added a clickable profile image, restructured with semantic tags (`header`, `main`, `section`, `footer`)
- **Part 4** (after Level 4): added the Contact Me form

## How to view it
Open `portfolio/index.html` in your browser, or use VS Code's Live Server extension.

## Status
🔄 In Progress — CSS styling and JavaScript interactivity coming once those topics are learned.
