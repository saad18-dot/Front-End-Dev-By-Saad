# HTML Exercises

Practice files and the working copy of the course's main project, kept here for quick reference while learning — separate from the "official" showcase copy in `/projects`, which is what gets linked/deployed for recruiters.

## Contents
- `portfolio-project/` — the 4-part portfolio project (index, education, experience, projects) built level-by-level through the HTML course. Same code as [`/projects/07-portfolio`](../../projects/07-portfolio).
- `student-resource-hub/` — the bonus project (sign-up form + iframe + table). Same code as [`/projects/08-student-resource-hub`](../../projects/08-student-resource-hub).

> Why duplicated? These files live here so they're easy to find while studying HTML tag-by-tag, and in `/projects` so they're easy for recruiters to find as finished work. Once CSS/JS get added, keep updating the `/projects` copy as the "real" one.
