Put your profile picture here as `profile.jpg` (or update the `src` in `index.html` to match your filename).
